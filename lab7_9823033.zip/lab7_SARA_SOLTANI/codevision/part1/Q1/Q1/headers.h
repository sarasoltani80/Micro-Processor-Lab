#ifndef _HEADERS_INCLUDED_
#define _HEADERS_INCLUDED_

#include <mega16.h>
#include <alcd.h>
#include <delay.h>

// Standard Input/Output functions
#include <stdio.h>

#include <subRoutines.h>

#endif
