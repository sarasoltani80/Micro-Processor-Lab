#ifndef _SUBROUTINES_INCLUDED_
#define _SUBROUTINES_INCLUDED_

void init(void);
void subRoutine1(void);

#endif
