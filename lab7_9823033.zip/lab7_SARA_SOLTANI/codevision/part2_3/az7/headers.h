#ifndef _HEADERS_INCLUDED_
#define _HEADERS_INCLUDED_

#include <mega16.h>
#include <stdio.h>
#include <string.h>
#include <alcd.h>
#include <stdbool.h>
#include <ctype.h>
#include <delay.h>

#endif
