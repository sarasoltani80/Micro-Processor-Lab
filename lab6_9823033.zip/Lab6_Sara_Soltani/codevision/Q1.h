#ifndef _Q1_INCLUDED_
#define _Q1_INCLUDED_

void subTask1();

#endif
