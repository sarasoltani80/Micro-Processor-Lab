#ifndef _Q2_INCLUDED_
#define _Q2_INCLUDED_

void subTask2();

#endif


