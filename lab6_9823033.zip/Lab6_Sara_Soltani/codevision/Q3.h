#ifndef _Q3_INCLUDED_
#define _Q3_INCLUDED_

void init_Q3();
void subTask3();

#endif
