#ifndef _HEADERS_INCLUDED_
#define _HEADERS_INCLUDED_

#include <mega16.h>

// Alphanumeric LCD functions
#include <alcd.h>
#include <delay.h>
#include <stdio.h>
#include <stdbool.h>

#endif
