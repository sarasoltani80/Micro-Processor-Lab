#include <mega16.h>
#include <delay.h>
//int count = 2;  
//int j = 0;
//int data;
//int num = 10;

flash unsigned char digit[]={0x3F, 0x06, 0x5B, 0x4F, 0x66, 0x6D, 0x7D,
0x07, 0x7F, 0x6F};

void func1(void) 
{
    int i;
    DDRB = 0xFF;
    PORTB = 0x00;
    for (i = 0; i < 4; i++) {
        PORTB = 0xFF; 
        delay_ms(500); 
        PORTB = 0x00; 
        delay_ms(500); 
    }
}

void func2(void){
    
    int i; 
    int number = 1;
    DDRB=0xFF;       // define port B as output
    for(i=0;i<24;i++)
    {        
       PORTB=number;  
       delay_ms(125);   
       number = number * 2;    
       if (number > 128){    
        number= 1;
       } 
    }
}

void func3(void){
    DDRA=0x00;
    DDRB=0xff;
    PORTB=PINA;
}

void func4(void) 
{
    int i;
    int count=9;
    DDRC = 0xFF; 
    DDRD = 0x0F;
    PORTD = 0xF0;   
    for (i = 0; i <= 9 ; i++) {
        PORTC = digit[count];
        delay_ms(400);       
        count --;
    }    
}

int func6(int num) { 
    int num2 = 0;
    if(!PIND.7) {
        num2 = (num / 1000) * 1000; //hezargan
    } else if (!PIND.6) {
        num2 = ((num % 1000)/100) * 100; //sadgan
    } else if (!PIND.5) {
        num2 = ((num % 100) / 10) * 10; //dahgan
    } else if (!PIND.4) {
        num2 = (num % 10);  //yekan
    }  
    num = num - num2;
    return num;
}

void func5(void)
{
    int data;
    int data1; 
    DDRA=0x00;
    DDRC=0xFF;
    DDRD = 0x0F;
    data=PINA;
    data1=data*10;
    while(data1)
    {       
        int i;
        for(i=0;i<500;i++)
        {
    
        int A=data1%10;   //yekan
        int B=(data1/10)%10;     //dahgan
        int C=(data1/100)%10;    //sadgan
        int D=data1/1000;       //hezargan
        
        PORTD=0b0111;
        PORTC=digit[A];
        delay_us(100);
        
        PORTD=0b1011;
        PORTC=digit[B]+0b10000000;
        delay_us(100);
        
        PORTD=0b1101;
        PORTC=digit[C];
        delay_us(100); 
              
        PORTD=0b1110;
        PORTC=digit[D];
        delay_us(100); 
         
        }
        
        data1 = func6(data1);
        delay_ms(200);
        data1=data1-2;
    }                
   
}


void main(void)
{
    func1();
    func2();  
    func4(); 
    //func3();
    while(1){
        func3(); 
        func5();
    }
}