#ifndef _myheader_INCLUDED_
#define _myheader_INCLUDED_

#include <io.h>
#include <delay.h>
#include <subroutines.h>

#define port_A 1
#define port_B 2
#define port_C 3
#define port_D 4

#endif