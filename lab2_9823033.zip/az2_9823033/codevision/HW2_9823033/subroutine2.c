#include <myheader.h>

void subroutine2(unsigned int port_out, unsigned char data){
 switch(port_out) {  
    case port_A :
        DDRA = 0xff;   
        PORTA = data;
    break;
    case port_B:
        DDRB = 0xff;  
        PORTB = data;
    break;
    case port_C:
        DDRC = 0xff;   
        PORTC = data;
    break;
    case port_D:
        DDRD = 0xff;   
        PORTD = data;
    break;
 }
 }