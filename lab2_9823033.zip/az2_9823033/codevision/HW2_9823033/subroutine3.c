#include <myheader.h>

void subroutine3(unsigned int count, unsigned int fasele){
    int i = 0;
    for(i = 0; i < count;i++) {
      subroutine2(port_B, 0xff);      
      delay_ms(fasele);
      subroutine2(port_B, 0x00);  
      delay_ms(fasele);
    }
}