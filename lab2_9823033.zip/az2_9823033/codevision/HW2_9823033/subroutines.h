#ifndef _subroutines_INCLUDED_
#define _subroutines_INCLUDED_

unsigned char subroutine1(unsigned int);
void subroutine2(unsigned int, unsigned char);
void subroutine3(unsigned int, unsigned int);
void subroutine4();
void subroutine5(int, int, int);

#endif