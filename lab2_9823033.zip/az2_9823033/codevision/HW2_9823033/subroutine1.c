#include <myheader.h>

unsigned char subroutine1(unsigned int port_in) {
 unsigned char data_in; 
 
 switch(port_in) {  
    case port_A :
        DDRA = 0x00;   
        data_in = PINA;
    break;
    case port_B:
        DDRB = 0x00;   
        data_in = PINB;
    break;
    case port_C:
        DDRC = 0x00;  
        data_in = PINC;
    break;
    case port_D:
        DDRD = 0x00;   
        data_in = PIND;
    break;
 }
 return data_in;
}