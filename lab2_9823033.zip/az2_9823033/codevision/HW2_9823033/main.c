#include <myheader.h>

void main(void)
{
subroutine3(6, 300); 
    while(1) {
        subroutine4();  
        subroutine5(9075, port_C, port_D);
    } 
}