#include <myheader.h>

void subroutine5(int data, int data_port, int enable_data) {
    int digit1, digit2, digit3, digit4;              
    unsigned char digits[] = {0x3F, 0x06, 0x5B, 0x4F, 0x66, 0x6D, 0x7D, 0x07, 0x7F, 0x6F}; // numbers from 0 to 9
    digit1 = data / 1000;   
    digit2 = (data % 1000)/100;
    digit3 = (data % 100) / 10;  
    digit4 = data % 10; 
    
    subroutine2(enable_data, 0xFE);               
    subroutine2(data_port, digits[digit1]);      
    delay_us(100);
    subroutine2(enable_data, 0xFD);              
    subroutine2(data_port, digits[digit2]);       
    delay_us(100);
    subroutine2(enable_data, 0xFB);              
    subroutine2(data_port, digits[digit3]);       
    delay_us(100);
    subroutine2(enable_data, 0xF7);               
    subroutine2(data_port, digits[digit4]);       
    delay_us(100);                  
}