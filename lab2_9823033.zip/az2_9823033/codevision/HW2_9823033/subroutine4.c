#include <myheader.h>

void subroutine4() {
    unsigned char data;  
    data = subroutine1(port_A);      
    subroutine2(port_B, data);    
}