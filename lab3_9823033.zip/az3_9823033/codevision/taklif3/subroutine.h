#ifndef _subroutine_INCLUDED_
#define _subroutine_INCLUDED_

void initialization(void);
void func1(char* familyname, char* id);
void func2(void);
void keypad(void);
char keypad3(void);
void func3(void);
void check_interrupt(void);
void speed(void);
void time(void);
void w(void);
void temp(void);
void func5(void);

#endif