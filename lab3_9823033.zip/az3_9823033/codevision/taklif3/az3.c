#include <myheader.h>

void main(void)
{
initialization();
func1("soltani","9823033");
func2();
func3();

#asm("sei")
check_interrupt();

#asm("cli");
func5();

while (1){}
}