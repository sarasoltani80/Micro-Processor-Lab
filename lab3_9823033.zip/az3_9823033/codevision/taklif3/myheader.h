#ifndef _myheader_INCLUDED_
#define _myheader_INCLUDED_

#include <mega16.h>
#include <stdio.h>
#include <delay.h>
#include <io.h>
#include <string.h>
#include <stdlib.h>
#include <alcd.h>
#include <subroutine.h>

#endif